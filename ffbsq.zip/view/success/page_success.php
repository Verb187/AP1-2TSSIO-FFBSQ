<!DOCTYPE html>
<html>
<head>
    <title>Success Page</title>
</head>
<body>
    <h1>Success!</h1>
    <p>Congratulations! Your action was successful.</p>
</body>
</html>